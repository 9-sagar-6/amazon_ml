import os
import re
import numpy as np
import pandas as pd
from collections import defaultdict
from sklearn.feature_extraction.text import HashingVectorizer
from utils import clean_text, extract_numbers

class MultiPassBlocker:
    """
    Multi-Pass Blocking Engine for Large-Scale Entity Resolution.
    - Pass 1: HashingVectorizer char 3-gram L2-normalized Cosine Similarity Matrix Dot Product.
    - Pass 2: Inverted Index Key Blocking (Numeric tokens, PIN/Zip codes).
    """
    def __init__(self, top_k=25, min_tfidf_sim=0.15, batch_size=10000):
        self.top_k = top_k
        self.min_tfidf_sim = min_tfidf_sim
        self.batch_size = batch_size

    def generate_candidates_for_country(self, s1_df: pd.DataFrame, pool_df: pd.DataFrame) -> dict:
        candidates_dict = defaultdict(set)
        if len(s1_df) == 0 or len(pool_df) == 0:
            return candidates_dict

        if "clean_combined" not in pool_df.columns:
            pool_df["clean_name"] = pool_df["business_name"].fillna("").apply(clean_text)
            pool_df["clean_address"] = pool_df["business_address"].fillna("").apply(clean_text)
            pool_df["clean_combined"] = pool_df["clean_name"] + " " + pool_df["clean_address"]

        if "clean_combined" not in s1_df.columns:
            s1_df["clean_name"] = s1_df["business_name"].fillna("").apply(clean_text)
            s1_df["clean_address"] = s1_df["business_address"].fillna("").apply(clean_text)
            s1_df["clean_combined"] = s1_df["clean_name"] + " " + s1_df["clean_address"]

        # Pass 1: HashingVectorizer (Memory-safe & blazing fast)
        vectorizer = HashingVectorizer(analyzer='char_wb', ngram_range=(3, 3), n_features=2**17, alternate_sign=False, norm='l2')
        pool_tfidf = vectorizer.transform(pool_df["clean_combined"])
        s1_tfidf = vectorizer.transform(s1_df["clean_combined"])

        pool_ids = pool_df["entity_id"].values
        s1_ids = s1_df["entity_id"].values

        num_s1 = len(s1_df)
        for start_idx in range(0, num_s1, self.batch_size):
            end_idx = min(start_idx + self.batch_size, num_s1)
            batch_vec = s1_tfidf[start_idx:end_idx]
            sim_matrix = batch_vec.dot(pool_tfidf.T)

            for i in range(end_idx - start_idx):
                s1_id = s1_ids[start_idx + i]
                row = sim_matrix[i].toarray().ravel()
                
                if len(row) <= self.top_k:
                    top_indices = np.argsort(-row)
                else:
                    top_indices = np.argpartition(-row, self.top_k)[:self.top_k]
                    top_indices = top_indices[np.argsort(-row[top_indices])]

                for idx in top_indices:
                    sim = float(row[idx])
                    if sim >= self.min_tfidf_sim:
                        candidates_dict[s1_id].add(pool_ids[idx])

        # Pass 2: Numeric Token & Zipcode Inverted Index Blocking
        num_index = defaultdict(list)
        for idx, row in pool_df.iterrows():
            cand_id = row["entity_id"]
            num_tokens = extract_numbers(row["clean_combined"])
            for num in num_tokens:
                if len(num) >= 4:
                    num_index[num].append(cand_id)

        for idx, row in s1_df.iterrows():
            s1_id = row["entity_id"]
            nums = extract_numbers(row["clean_combined"])
            for num in nums:
                if len(num) >= 4 and num in num_index:
                    for cand_id in num_index[num][:15]:
                        candidates_dict[s1_id].add(cand_id)

        return candidates_dict

    def run_blocking(self, s1_df: pd.DataFrame, s2_df: pd.DataFrame, s3_df: pd.DataFrame) -> dict:
        all_candidates = {}
        countries = s1_df["country"].unique()

        for country in countries:
            c_s1 = s1_df[s1_df["country"] == country].copy()
            c_s2 = s2_df[s2_df["country"] == country].copy()
            c_s3 = s3_df[s3_df["country"] == country].copy()
            c_pool = pd.concat([c_s2, c_s3], ignore_index=True)

            c_cands = self.generate_candidates_for_country(c_s1, c_pool)
            all_candidates.update(c_cands)

        for s1_id in s1_df["entity_id"]:
            if s1_id not in all_candidates:
                all_candidates[s1_id] = set()

        return all_candidates
